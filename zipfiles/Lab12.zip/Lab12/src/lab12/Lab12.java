/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab12;

/**
 *
 * @author brandon
 */
public class Lab12 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Account checking = new Checking("Brandon Norton", 1000);
        Account saving = new Savings("Brandon Norton", 200);
        Account cd = new Cd(3, "Brandon Norton", 200);

        //Test checking class
//        System.out.println(checking);
//        System.out.println("deposit(-5) returns " + checking.deposit(-5));
//        System.out.println(checking);
//        System.out.println("deposit(5) returns " + checking.deposit(5));
//        System.out.println(checking);
//        System.out.println("withdraw(-5) returns " + checking.withdraw(-5));
//        System.out.println(checking);
//        System.out.println("withdraw(100) returns " + checking.withdraw(100));
//        System.out.println(checking);
//        System.out.println("withdraw(890) returns " + checking.withdraw(890));
//        System.out.println(checking);
//        System.out.println("calling monthlyProcessing()");
//        checking.monthlyProcessing();
//        System.out.println(checking);
        //Test Saving class
//        System.out.println(saving);
//        System.out.println("deposit(-5) returns " + saving.deposit(-5));
//        System.out.println(saving);
//        System.out.println("deposit(5) returns "+ saving.deposit(5));
//        System.out.println(saving);
//        System.out.println("withdraw(-5) returns " + saving.withdraw(-5));
//        System.out.println(saving);
//        System.out.println("withdraw(900) returns " + saving.withdraw(900));
//        System.out.println(saving);
//        System.out.println("withdraw(100) returns " + saving.withdraw(100));
//        System.out.println(saving);
//        System.out.println("withdraw(10) returns " + saving.withdraw(10));
//        System.out.println(saving);
//        System.out.println("withdraw(10) returns " + saving.withdraw(10));
//        System.out.println(saving);
//        System.out.println("withdraw(10) returns " + saving.withdraw(10));
//        System.out.println(saving);
//        System.out.println("withdraw(10) returns " + saving.withdraw(10));
//        System.out.println(saving);
//        System.out.println("calling monthlyProcessing()");
//        saving.monthlyProcessing();
//        System.out.println(saving);
        //Test Cd class
//        System.out.println(cd);
//        System.out.println("deposit(10) returns " + cd.deposit(10));
//        System.out.println(cd);
//        System.out.println("withdraw(5) returns " + cd.withdraw(5));
//        System.out.println(cd);
//        System.out.println("calling monthlyProcessing()");
//        cd.monthlyProcessing();
//        System.out.println(cd);
//        System.out.println("calling monthlyProcessing()");
//        cd.monthlyProcessing();
//        System.out.println(cd);
//        System.out.println("calling monthlyProcessing()");
//        cd.monthlyProcessing();
//        System.out.println(cd);
//        System.out.println("deposit(-5) returns " + cd.deposit(-5));
//        System.out.println(cd);
//        System.out.println("deposit(20) returns " + cd.deposit(20));
//        System.out.println(cd);
//        System.out.println("withdraw(-5) returns " + cd.withdraw(-5));
//        System.out.println(cd);
//        System.out.println("withdraw(20) returns " + cd.withdraw(20));
//        System.out.println(cd);
//        System.out.println("withdraw(200) returns " + cd.withdraw(200));
//        System.out.println(cd);
//        System.out.println("calling monthlyProcessing()");
//        cd.monthlyProcessing();
//        System.out.println(cd);
    }
}
