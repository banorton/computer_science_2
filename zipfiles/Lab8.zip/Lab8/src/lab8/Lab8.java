/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab8;

/**
 *
 * @author banor
 */
public class Lab8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
//        Account accBrandon = new Account(AccountType.CHECKING, "Brandon", -1000.00);
//        Account accBob = new Account(AccountType.CD, "Bob", 1000.00);
//        Account accFoo = new Account(AccountType.SAVINGS, "Foo", 1000.00);
//        
//        System.out.println(accBrandon);
//        System.out.println(accBrandon.deposit(-100.00));
//        System.out.println(accBrandon);
//        System.out.println(accBrandon.withdrawl(-100.00));
//        System.out.println(accBrandon);
//        accBrandon.monthlyProcessing();
//        System.out.println(accBrandon);
//        
//        accBob.monthlyProcessing();
//        System.out.println(accBob);
//        
//        accFoo.monthlyProcessing();
//        System.out.println(accFoo);

    Bank bank = new Bank();
    
    System.out.println(bank.openAccount(AccountType.CHECKING, "Brandon", 1000.00));
    System.out.println(bank.openAccount(AccountType.CD, "Bob", 1000.00));
    System.out.println(bank.openAccount(AccountType.SAVINGS, "Foo", 1000.00));
    
    System.out.println(bank.closeAccount(3));
    
    System.out.println(bank.depositAccount(1, 100.00));
    System.out.println(bank.withdrawlAccount(1, 100.00));
    System.out.println(bank.toStringAccount(1));
    bank.monthlyProcessing();
    System.out.println(bank.toStringAccount(1));
    
    }
    
}
